﻿namespace HospitalManagement
{
    partial class frm_Third_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Third_Info));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btn_LogoutAdmin = new System.Windows.Forms.Button();
            this.lbl_GreetingAdmin = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_PatientInformation = new System.Windows.Forms.Button();
            this.btn_DoctorInformation = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.btn_LogoutAdmin);
            this.panel1.Controls.Add(this.lbl_GreetingAdmin);
            this.panel1.Location = new System.Drawing.Point(101, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(856, 112);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(614, 31);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 40);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // btn_LogoutAdmin
            // 
            this.btn_LogoutAdmin.BackColor = System.Drawing.Color.PowderBlue;
            this.btn_LogoutAdmin.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LogoutAdmin.Location = new System.Drawing.Point(595, 21);
            this.btn_LogoutAdmin.Name = "btn_LogoutAdmin";
            this.btn_LogoutAdmin.Size = new System.Drawing.Size(242, 71);
            this.btn_LogoutAdmin.TabIndex = 1;
            this.btn_LogoutAdmin.Text = "        LOG OUT";
            this.btn_LogoutAdmin.UseVisualStyleBackColor = false;
            this.btn_LogoutAdmin.Click += new System.EventHandler(this.btn_LogoutAdmin_Click);
            // 
            // lbl_GreetingAdmin
            // 
            this.lbl_GreetingAdmin.AutoSize = true;
            this.lbl_GreetingAdmin.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GreetingAdmin.ForeColor = System.Drawing.Color.Cyan;
            this.lbl_GreetingAdmin.Location = new System.Drawing.Point(40, 31);
            this.lbl_GreetingAdmin.Name = "lbl_GreetingAdmin";
            this.lbl_GreetingAdmin.Size = new System.Drawing.Size(268, 37);
            this.lbl_GreetingAdmin.TabIndex = 0;
            this.lbl_GreetingAdmin.Text = "HELLO ADMIN!";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-5, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1289, 659);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btn_PatientInformation);
            this.flowLayoutPanel1.Controls.Add(this.btn_DoctorInformation);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(101, 156);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(326, 76);
            this.flowLayoutPanel1.TabIndex = 2;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // btn_PatientInformation
            // 
            this.btn_PatientInformation.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PatientInformation.ForeColor = System.Drawing.Color.Teal;
            this.btn_PatientInformation.Location = new System.Drawing.Point(3, 3);
            this.btn_PatientInformation.Name = "btn_PatientInformation";
            this.btn_PatientInformation.Size = new System.Drawing.Size(153, 64);
            this.btn_PatientInformation.TabIndex = 0;
            this.btn_PatientInformation.Text = "PATIENT";
            this.btn_PatientInformation.UseVisualStyleBackColor = true;
            this.btn_PatientInformation.Click += new System.EventHandler(this.btn_PatientInformation_Click);
            // 
            // btn_DoctorInformation
            // 
            this.btn_DoctorInformation.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DoctorInformation.ForeColor = System.Drawing.Color.Teal;
            this.btn_DoctorInformation.Location = new System.Drawing.Point(162, 3);
            this.btn_DoctorInformation.Name = "btn_DoctorInformation";
            this.btn_DoctorInformation.Size = new System.Drawing.Size(153, 64);
            this.btn_DoctorInformation.TabIndex = 1;
            this.btn_DoctorInformation.Text = "DOCTOR";
            this.btn_DoctorInformation.UseVisualStyleBackColor = true;
            this.btn_DoctorInformation.Click += new System.EventHandler(this.btn_DoctorInformation_Click);
            // 
            // frm_Third_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1278, 662);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frm_Third_Info";
            this.Text = "Patient and Doctor Information";
            this.Load += new System.EventHandler(this.frm_Third_Info_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_LogoutAdmin;
        private System.Windows.Forms.Label lbl_GreetingAdmin;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btn_PatientInformation;
        private System.Windows.Forms.Button btn_DoctorInformation;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}