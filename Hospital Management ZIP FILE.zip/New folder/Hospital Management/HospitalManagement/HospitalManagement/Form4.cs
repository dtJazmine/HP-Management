﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalManagement
{
    public partial class frm_DoctorInformation : Form
    {
      
        public frm_DoctorInformation()
        {
            InitializeComponent();

      
        }

        
        public void loading()
        {
            SqlConnection con = new SqlConnection("Data Source =LAPTOP-V2580G7H; Initial Catalog = DB_HospitalManagementSystem; Integrated Security = True");
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM TBL_DOCTOR_INFORMATION", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridViewPatient.DataSource = ds.Tables[0];
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtb_Search_TextChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void frm_DoctorInformation_Load(object sender, EventArgs e)
        {
            loading();
        }

        private void btn_DoctorLoad_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source =LAPTOP-V2580G7H; Initial Catalog = DB_HospitalManagementSystem; Integrated Security = True");
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO TBL_DOCTOR_INFORMATION VALUES (@DOCTOR_ID, @DoctorFirstName, @DoctorLastName, @DoctorFee, @DoctorContact, @DoctorSchedule, @DoctorSpecialist)",con);
            cmd.Parameters.AddWithValue("@DOCTOR_ID", int.Parse(txtb_DoctorID.Text));
            cmd.Parameters.AddWithValue("@DoctorFirstName", (txtb_DoctorFname.Text));
            cmd.Parameters.AddWithValue("@DoctorLastName", (txtb_DoctorLname.Text));
            cmd.Parameters.AddWithValue("@DoctorFee", int.Parse(txtb_DoctorFee.Text));
            cmd.Parameters.AddWithValue("@DoctorContact", (txtb_DoctorContact.Text));
            cmd.Parameters.AddWithValue("@DoctorSchedule", (txtb_DoctorSchedule.Text));
            cmd.Parameters.AddWithValue("@DoctorSpecialist", (txtb_DoctorSpecialist.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Saved");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source =LAPTOP-V2580G7H; Initial Catalog = DB_HospitalManagementSystem; Integrated Security = True");
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM TBL_DOCTOR_INFORMATION", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewPatient.DataSource = dt;


        }

        private void btn_DoctorUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source =LAPTOP-V2580G7H; Initial Catalog = DB_HospitalManagementSystem; Integrated Security = True");
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE TBL_DOCTOR_INFORMATION SET FirstName=@DoctorFirstName, LastName=@DoctorLastName, Fee=@DoctorFee, Contact=@DoctorContact, Schedule=@DoctorSchedule, Specialist=@DoctorSpecialist WHERE ID=@DOCTOR_ID", con);
            cmd.Parameters.AddWithValue("@DOCTOR_ID", int.Parse(txtb_DoctorID.Text));
            cmd.Parameters.AddWithValue("@DoctorFirstName", (txtb_DoctorFname.Text));
            cmd.Parameters.AddWithValue("@DoctorLastName", (txtb_DoctorLname.Text));
            cmd.Parameters.AddWithValue("@DoctorFee", int.Parse(txtb_DoctorFee.Text));
            cmd.Parameters.AddWithValue("@DoctorContact", (txtb_DoctorContact.Text));
            cmd.Parameters.AddWithValue("@DoctorSchedule", (txtb_DoctorSchedule.Text));
            cmd.Parameters.AddWithValue("@DoctorSpecialist", (txtb_DoctorSpecialist.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Update");
        }

        private void btn_DoctorDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source =LAPTOP-V2580G7H; Initial Catalog = DB_HospitalManagementSystem; Integrated Security = True");
            con.Open();
            SqlCommand cmd = new SqlCommand("DELETE TBL_DOCTOR_INFORMATION WHERE  ID=@DOCTOR_ID", con);
            cmd.Parameters.AddWithValue("@DOCTOR_ID", int.Parse(txtb_DoctorID.Text));
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted");
        }

        private void btn_DoctorBacktoform3_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_Third_Info frm = new frm_Third_Info();
            frm.Show();
        }
    }
}
