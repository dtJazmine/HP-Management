﻿namespace HospitalManagement
{
    partial class Frm_Front
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Front));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_NameHospital = new System.Windows.Forms.Label();
            this.lbl_loginas = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btn_Admin = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btn_Cashier = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.lbl_HospitalContactNumber = new System.Windows.Forms.Label();
            this.lbl_HospitalAddress = new System.Windows.Forms.Label();
            this.lbl_HospitalEmail = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel1.Controls.Add(this.lbl_HospitalEmail);
            this.panel1.Controls.Add(this.lbl_HospitalAddress);
            this.panel1.Controls.Add(this.lbl_HospitalContactNumber);
            this.panel1.Controls.Add(this.lbl_NameHospital);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(108, 26);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1345, 161);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(203, 130);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_NameHospital
            // 
            this.lbl_NameHospital.AutoSize = true;
            this.lbl_NameHospital.Font = new System.Drawing.Font("Times New Roman", 40F, System.Drawing.FontStyle.Bold);
            this.lbl_NameHospital.ForeColor = System.Drawing.Color.Cyan;
            this.lbl_NameHospital.Location = new System.Drawing.Point(190, 22);
            this.lbl_NameHospital.Name = "lbl_NameHospital";
            this.lbl_NameHospital.Size = new System.Drawing.Size(1048, 76);
            this.lbl_NameHospital.TabIndex = 1;
            this.lbl_NameHospital.Text = "ANGELES LIFELINE HOSPITAL";
            // 
            // lbl_loginas
            // 
            this.lbl_loginas.AutoSize = true;
            this.lbl_loginas.BackColor = System.Drawing.Color.Cyan;
            this.lbl_loginas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_loginas.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginas.ForeColor = System.Drawing.Color.Black;
            this.lbl_loginas.Location = new System.Drawing.Point(735, 337);
            this.lbl_loginas.Name = "lbl_loginas";
            this.lbl_loginas.Size = new System.Drawing.Size(119, 34);
            this.lbl_loginas.TabIndex = 1;
            this.lbl_loginas.Text = "Login as";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(495, 444);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 90);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // btn_Admin
            // 
            this.btn_Admin.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Admin.Location = new System.Drawing.Point(440, 564);
            this.btn_Admin.Name = "btn_Admin";
            this.btn_Admin.Size = new System.Drawing.Size(205, 50);
            this.btn_Admin.TabIndex = 3;
            this.btn_Admin.Text = "Admin";
            this.btn_Admin.UseVisualStyleBackColor = true;
            this.btn_Admin.Click += new System.EventHandler(this.btn_Admin_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(981, 444);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 90);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // btn_Cashier
            // 
            this.btn_Cashier.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cashier.Location = new System.Drawing.Point(928, 564);
            this.btn_Cashier.Name = "btn_Cashier";
            this.btn_Cashier.Size = new System.Drawing.Size(205, 50);
            this.btn_Cashier.TabIndex = 5;
            this.btn_Cashier.Text = "Cashier";
            this.btn_Cashier.UseVisualStyleBackColor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(3, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(1565, 869);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // lbl_HospitalContactNumber
            // 
            this.lbl_HospitalContactNumber.AutoSize = true;
            this.lbl_HospitalContactNumber.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HospitalContactNumber.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_HospitalContactNumber.Location = new System.Drawing.Point(614, 98);
            this.lbl_HospitalContactNumber.Name = "lbl_HospitalContactNumber";
            this.lbl_HospitalContactNumber.Size = new System.Drawing.Size(119, 17);
            this.lbl_HospitalContactNumber.TabIndex = 7;
            this.lbl_HospitalContactNumber.Text = "(0993)-84402442";
            // 
            // lbl_HospitalAddress
            // 
            this.lbl_HospitalAddress.AutoSize = true;
            this.lbl_HospitalAddress.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HospitalAddress.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_HospitalAddress.Location = new System.Drawing.Point(603, 114);
            this.lbl_HospitalAddress.Name = "lbl_HospitalAddress";
            this.lbl_HospitalAddress.Size = new System.Drawing.Size(137, 17);
            this.lbl_HospitalAddress.TabIndex = 8;
            this.lbl_HospitalAddress.Text = "124 RealState, USA";
            // 
            // lbl_HospitalEmail
            // 
            this.lbl_HospitalEmail.AutoSize = true;
            this.lbl_HospitalEmail.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HospitalEmail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_HospitalEmail.Location = new System.Drawing.Point(563, 130);
            this.lbl_HospitalEmail.Name = "lbl_HospitalEmail";
            this.lbl_HospitalEmail.Size = new System.Drawing.Size(233, 17);
            this.lbl_HospitalEmail.TabIndex = 9;
            this.lbl_HospitalEmail.Text = "angeleslifelinehospital@gmail.com";
            // 
            // Frm_Front
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1569, 871);
            this.Controls.Add(this.btn_Cashier);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btn_Admin);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lbl_loginas);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox4);
            this.Name = "Frm_Front";
            this.Text = "Front";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_NameHospital;
        private System.Windows.Forms.Label lbl_loginas;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btn_Admin;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btn_Cashier;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label lbl_HospitalContactNumber;
        private System.Windows.Forms.Label lbl_HospitalEmail;
        private System.Windows.Forms.Label lbl_HospitalAddress;
    }
}

