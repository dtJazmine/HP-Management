﻿namespace HospitalManagement
{
    partial class frm_DoctorInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_DoctorInformation));
            this.dataGridViewPatient = new System.Windows.Forms.DataGridView();
            this.txtb_DoctorSearch = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_DoctorInsert = new System.Windows.Forms.Button();
            this.btn_DoctorDelete = new System.Windows.Forms.Button();
            this.btn_DoctorUpdate = new System.Windows.Forms.Button();
            this.txtb_DoctorFname = new System.Windows.Forms.TextBox();
            this.txtb_DoctorLname = new System.Windows.Forms.TextBox();
            this.txtb_DoctorSpecialist = new System.Windows.Forms.TextBox();
            this.lbl_DoctorFname = new System.Windows.Forms.Label();
            this.lbl_DoctorLname = new System.Windows.Forms.Label();
            this.lbl_DoctorSpecialist = new System.Windows.Forms.Label();
            this.btn_DoctorSearch = new System.Windows.Forms.Button();
            this.btn_DoctorBacktoform3 = new System.Windows.Forms.Button();
            this.lbl_DoctorID = new System.Windows.Forms.Label();
            this.txtb_DoctorID = new System.Windows.Forms.TextBox();
            this.lbl_DoctorContact = new System.Windows.Forms.Label();
            this.lbl_DoctorFee = new System.Windows.Forms.Label();
            this.lbl_DoctorSchedule = new System.Windows.Forms.Label();
            this.txtb_DoctorContact = new System.Windows.Forms.TextBox();
            this.txtb_DoctorFee = new System.Windows.Forms.TextBox();
            this.txtb_DoctorSchedule = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPatient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewPatient
            // 
            this.dataGridViewPatient.AllowUserToAddRows = false;
            this.dataGridViewPatient.AllowUserToDeleteRows = false;
            this.dataGridViewPatient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPatient.Location = new System.Drawing.Point(49, 339);
            this.dataGridViewPatient.Name = "dataGridViewPatient";
            this.dataGridViewPatient.ReadOnly = true;
            this.dataGridViewPatient.RowHeadersWidth = 51;
            this.dataGridViewPatient.RowTemplate.Height = 24;
            this.dataGridViewPatient.Size = new System.Drawing.Size(1238, 520);
            this.dataGridViewPatient.TabIndex = 0;
            this.dataGridViewPatient.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // txtb_DoctorSearch
            // 
            this.txtb_DoctorSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_DoctorSearch.Location = new System.Drawing.Point(478, 285);
            this.txtb_DoctorSearch.Name = "txtb_DoctorSearch";
            this.txtb_DoctorSearch.Size = new System.Drawing.Size(571, 38);
            this.txtb_DoctorSearch.TabIndex = 2;
            this.txtb_DoctorSearch.TextChanged += new System.EventHandler(this.txtb_Search_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(223, 278);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 56);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btn_DoctorInsert
            // 
            this.btn_DoctorInsert.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DoctorInsert.Location = new System.Drawing.Point(118, 50);
            this.btn_DoctorInsert.Name = "btn_DoctorInsert";
            this.btn_DoctorInsert.Size = new System.Drawing.Size(131, 41);
            this.btn_DoctorInsert.TabIndex = 5;
            this.btn_DoctorInsert.Text = "INSERT";
            this.btn_DoctorInsert.UseVisualStyleBackColor = true;
            this.btn_DoctorInsert.Click += new System.EventHandler(this.btn_DoctorLoad_Click);
            // 
            // btn_DoctorDelete
            // 
            this.btn_DoctorDelete.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DoctorDelete.Location = new System.Drawing.Point(118, 209);
            this.btn_DoctorDelete.Name = "btn_DoctorDelete";
            this.btn_DoctorDelete.Size = new System.Drawing.Size(131, 40);
            this.btn_DoctorDelete.TabIndex = 6;
            this.btn_DoctorDelete.Text = "DELETE";
            this.btn_DoctorDelete.UseVisualStyleBackColor = true;
            this.btn_DoctorDelete.Click += new System.EventHandler(this.btn_DoctorDelete_Click);
            // 
            // btn_DoctorUpdate
            // 
            this.btn_DoctorUpdate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DoctorUpdate.Location = new System.Drawing.Point(118, 128);
            this.btn_DoctorUpdate.Name = "btn_DoctorUpdate";
            this.btn_DoctorUpdate.Size = new System.Drawing.Size(131, 40);
            this.btn_DoctorUpdate.TabIndex = 7;
            this.btn_DoctorUpdate.Text = "UPDATE";
            this.btn_DoctorUpdate.UseVisualStyleBackColor = true;
            this.btn_DoctorUpdate.Click += new System.EventHandler(this.btn_DoctorUpdate_Click);
            // 
            // txtb_DoctorFname
            // 
            this.txtb_DoctorFname.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_DoctorFname.Location = new System.Drawing.Point(463, 117);
            this.txtb_DoctorFname.Name = "txtb_DoctorFname";
            this.txtb_DoctorFname.Size = new System.Drawing.Size(218, 27);
            this.txtb_DoctorFname.TabIndex = 8;
            // 
            // txtb_DoctorLname
            // 
            this.txtb_DoctorLname.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_DoctorLname.Location = new System.Drawing.Point(463, 167);
            this.txtb_DoctorLname.Name = "txtb_DoctorLname";
            this.txtb_DoctorLname.Size = new System.Drawing.Size(218, 27);
            this.txtb_DoctorLname.TabIndex = 9;
            // 
            // txtb_DoctorSpecialist
            // 
            this.txtb_DoctorSpecialist.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_DoctorSpecialist.Location = new System.Drawing.Point(463, 222);
            this.txtb_DoctorSpecialist.Name = "txtb_DoctorSpecialist";
            this.txtb_DoctorSpecialist.Size = new System.Drawing.Size(218, 27);
            this.txtb_DoctorSpecialist.TabIndex = 10;
            // 
            // lbl_DoctorFname
            // 
            this.lbl_DoctorFname.AutoSize = true;
            this.lbl_DoctorFname.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DoctorFname.Location = new System.Drawing.Point(301, 117);
            this.lbl_DoctorFname.Name = "lbl_DoctorFname";
            this.lbl_DoctorFname.Size = new System.Drawing.Size(124, 25);
            this.lbl_DoctorFname.TabIndex = 11;
            this.lbl_DoctorFname.Text = "First Name";
            // 
            // lbl_DoctorLname
            // 
            this.lbl_DoctorLname.AutoSize = true;
            this.lbl_DoctorLname.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DoctorLname.Location = new System.Drawing.Point(301, 167);
            this.lbl_DoctorLname.Name = "lbl_DoctorLname";
            this.lbl_DoctorLname.Size = new System.Drawing.Size(121, 25);
            this.lbl_DoctorLname.TabIndex = 12;
            this.lbl_DoctorLname.Text = "Last Name";
            // 
            // lbl_DoctorSpecialist
            // 
            this.lbl_DoctorSpecialist.AutoSize = true;
            this.lbl_DoctorSpecialist.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DoctorSpecialist.Location = new System.Drawing.Point(301, 224);
            this.lbl_DoctorSpecialist.Name = "lbl_DoctorSpecialist";
            this.lbl_DoctorSpecialist.Size = new System.Drawing.Size(104, 25);
            this.lbl_DoctorSpecialist.TabIndex = 13;
            this.lbl_DoctorSpecialist.Text = "Specialist";
            // 
            // btn_DoctorSearch
            // 
            this.btn_DoctorSearch.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DoctorSearch.Location = new System.Drawing.Point(306, 284);
            this.btn_DoctorSearch.Name = "btn_DoctorSearch";
            this.btn_DoctorSearch.Size = new System.Drawing.Size(131, 39);
            this.btn_DoctorSearch.TabIndex = 14;
            this.btn_DoctorSearch.Text = "SEARCH";
            this.btn_DoctorSearch.UseVisualStyleBackColor = true;
            this.btn_DoctorSearch.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_DoctorBacktoform3
            // 
            this.btn_DoctorBacktoform3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_DoctorBacktoform3.BackgroundImage")));
            this.btn_DoctorBacktoform3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DoctorBacktoform3.Location = new System.Drawing.Point(12, 12);
            this.btn_DoctorBacktoform3.Name = "btn_DoctorBacktoform3";
            this.btn_DoctorBacktoform3.Size = new System.Drawing.Size(59, 52);
            this.btn_DoctorBacktoform3.TabIndex = 15;
            this.btn_DoctorBacktoform3.UseVisualStyleBackColor = true;
            this.btn_DoctorBacktoform3.Click += new System.EventHandler(this.btn_DoctorBacktoform3_Click);
            // 
            // lbl_DoctorID
            // 
            this.lbl_DoctorID.AutoSize = true;
            this.lbl_DoctorID.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DoctorID.Location = new System.Drawing.Point(303, 65);
            this.lbl_DoctorID.Name = "lbl_DoctorID";
            this.lbl_DoctorID.Size = new System.Drawing.Size(114, 25);
            this.lbl_DoctorID.TabIndex = 16;
            this.lbl_DoctorID.Text = "Doctor ID";
            // 
            // txtb_DoctorID
            // 
            this.txtb_DoctorID.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_DoctorID.Location = new System.Drawing.Point(463, 65);
            this.txtb_DoctorID.Name = "txtb_DoctorID";
            this.txtb_DoctorID.Size = new System.Drawing.Size(218, 27);
            this.txtb_DoctorID.TabIndex = 17;
            // 
            // lbl_DoctorContact
            // 
            this.lbl_DoctorContact.AutoSize = true;
            this.lbl_DoctorContact.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DoctorContact.Location = new System.Drawing.Point(788, 78);
            this.lbl_DoctorContact.Name = "lbl_DoctorContact";
            this.lbl_DoctorContact.Size = new System.Drawing.Size(93, 25);
            this.lbl_DoctorContact.TabIndex = 18;
            this.lbl_DoctorContact.Text = "Contact";
            // 
            // lbl_DoctorFee
            // 
            this.lbl_DoctorFee.AutoSize = true;
            this.lbl_DoctorFee.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DoctorFee.Location = new System.Drawing.Point(791, 128);
            this.lbl_DoctorFee.Name = "lbl_DoctorFee";
            this.lbl_DoctorFee.Size = new System.Drawing.Size(49, 25);
            this.lbl_DoctorFee.TabIndex = 19;
            this.lbl_DoctorFee.Text = "Fee";
            // 
            // lbl_DoctorSchedule
            // 
            this.lbl_DoctorSchedule.AutoSize = true;
            this.lbl_DoctorSchedule.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DoctorSchedule.Location = new System.Drawing.Point(779, 172);
            this.lbl_DoctorSchedule.Name = "lbl_DoctorSchedule";
            this.lbl_DoctorSchedule.Size = new System.Drawing.Size(102, 25);
            this.lbl_DoctorSchedule.TabIndex = 20;
            this.lbl_DoctorSchedule.Text = "Schedule";
            // 
            // txtb_DoctorContact
            // 
            this.txtb_DoctorContact.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_DoctorContact.Location = new System.Drawing.Point(959, 78);
            this.txtb_DoctorContact.Name = "txtb_DoctorContact";
            this.txtb_DoctorContact.Size = new System.Drawing.Size(216, 27);
            this.txtb_DoctorContact.TabIndex = 21;
            // 
            // txtb_DoctorFee
            // 
            this.txtb_DoctorFee.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_DoctorFee.Location = new System.Drawing.Point(959, 128);
            this.txtb_DoctorFee.Name = "txtb_DoctorFee";
            this.txtb_DoctorFee.Size = new System.Drawing.Size(216, 27);
            this.txtb_DoctorFee.TabIndex = 22;
            // 
            // txtb_DoctorSchedule
            // 
            this.txtb_DoctorSchedule.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_DoctorSchedule.Location = new System.Drawing.Point(959, 176);
            this.txtb_DoctorSchedule.Name = "txtb_DoctorSchedule";
            this.txtb_DoctorSchedule.Size = new System.Drawing.Size(216, 27);
            this.txtb_DoctorSchedule.TabIndex = 23;
            // 
            // frm_DoctorInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1343, 880);
            this.Controls.Add(this.txtb_DoctorSchedule);
            this.Controls.Add(this.txtb_DoctorFee);
            this.Controls.Add(this.txtb_DoctorContact);
            this.Controls.Add(this.lbl_DoctorSchedule);
            this.Controls.Add(this.lbl_DoctorFee);
            this.Controls.Add(this.lbl_DoctorContact);
            this.Controls.Add(this.txtb_DoctorID);
            this.Controls.Add(this.lbl_DoctorID);
            this.Controls.Add(this.btn_DoctorBacktoform3);
            this.Controls.Add(this.btn_DoctorSearch);
            this.Controls.Add(this.lbl_DoctorSpecialist);
            this.Controls.Add(this.lbl_DoctorLname);
            this.Controls.Add(this.lbl_DoctorFname);
            this.Controls.Add(this.txtb_DoctorSpecialist);
            this.Controls.Add(this.txtb_DoctorLname);
            this.Controls.Add(this.txtb_DoctorFname);
            this.Controls.Add(this.btn_DoctorUpdate);
            this.Controls.Add(this.btn_DoctorDelete);
            this.Controls.Add(this.btn_DoctorInsert);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtb_DoctorSearch);
            this.Controls.Add(this.dataGridViewPatient);
            this.Name = "frm_DoctorInformation";
            this.Text = "Doctor Information";
            this.Load += new System.EventHandler(this.frm_DoctorInformation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPatient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewPatient;
        private System.Windows.Forms.TextBox txtb_DoctorSearch;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_DoctorInsert;
        private System.Windows.Forms.Button btn_DoctorDelete;
        private System.Windows.Forms.Button btn_DoctorUpdate;
        private System.Windows.Forms.TextBox txtb_DoctorFname;
        private System.Windows.Forms.TextBox txtb_DoctorLname;
        private System.Windows.Forms.TextBox txtb_DoctorSpecialist;
        private System.Windows.Forms.Label lbl_DoctorFname;
        private System.Windows.Forms.Label lbl_DoctorLname;
        private System.Windows.Forms.Label lbl_DoctorSpecialist;
        private System.Windows.Forms.Button btn_DoctorSearch;
        private System.Windows.Forms.Button btn_DoctorBacktoform3;
        private System.Windows.Forms.Label lbl_DoctorID;
        private System.Windows.Forms.TextBox txtb_DoctorID;
        private System.Windows.Forms.Label lbl_DoctorContact;
        private System.Windows.Forms.Label lbl_DoctorFee;
        private System.Windows.Forms.Label lbl_DoctorSchedule;
        private System.Windows.Forms.TextBox txtb_DoctorContact;
        private System.Windows.Forms.TextBox txtb_DoctorFee;
        private System.Windows.Forms.TextBox txtb_DoctorSchedule;
    }
}