﻿namespace HospitalManagement
{
    partial class frm_PatientInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_PatientInformation));
            this.btn_PatientBacktoform3 = new System.Windows.Forms.Button();
            this.txtb_PatientEmail = new System.Windows.Forms.TextBox();
            this.txtb_PatientIlness = new System.Windows.Forms.TextBox();
            this.txtb_PatientContact = new System.Windows.Forms.TextBox();
            this.lbl_PatientGender = new System.Windows.Forms.Label();
            this.lbl_PatiendAge = new System.Windows.Forms.Label();
            this.lbl_PatientContact = new System.Windows.Forms.Label();
            this.txtb_PatientID = new System.Windows.Forms.TextBox();
            this.lbl_PatientID = new System.Windows.Forms.Label();
            this.btn_PatientSearch = new System.Windows.Forms.Button();
            this.lbl_PatientMname = new System.Windows.Forms.Label();
            this.lbl_PatientLname = new System.Windows.Forms.Label();
            this.lbl_PatientFname = new System.Windows.Forms.Label();
            this.txtb_PatientMname = new System.Windows.Forms.TextBox();
            this.txtb_PatientLname = new System.Windows.Forms.TextBox();
            this.txtb_PatientFname = new System.Windows.Forms.TextBox();
            this.btn_PatientUpdate = new System.Windows.Forms.Button();
            this.btn_PatientDelete = new System.Windows.Forms.Button();
            this.btn_PatientInsert = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtb_PatientSearch = new System.Windows.Forms.TextBox();
            this.dataGridViewPatient = new System.Windows.Forms.DataGridView();
            this.txtb_PatientAge = new System.Windows.Forms.TextBox();
            this.lbl_PatientIlness = new System.Windows.Forms.Label();
            this.lbl_PatientEmail = new System.Windows.Forms.Label();
            this.cmb_PatientGender = new System.Windows.Forms.ComboBox();
            this.lbl_PatientMedicine = new System.Windows.Forms.Label();
            this.lbl_PatientRoom = new System.Windows.Forms.Label();
            this.txtb_PatientMedicine = new System.Windows.Forms.TextBox();
            this.txtb_PatientRoom = new System.Windows.Forms.TextBox();
            this.lbl_PatientAddress = new System.Windows.Forms.Label();
            this.txtb_PatientAddress = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPatient)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_PatientBacktoform3
            // 
            this.btn_PatientBacktoform3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_PatientBacktoform3.BackgroundImage")));
            this.btn_PatientBacktoform3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PatientBacktoform3.Location = new System.Drawing.Point(25, 12);
            this.btn_PatientBacktoform3.Name = "btn_PatientBacktoform3";
            this.btn_PatientBacktoform3.Size = new System.Drawing.Size(59, 52);
            this.btn_PatientBacktoform3.TabIndex = 16;
            this.btn_PatientBacktoform3.UseVisualStyleBackColor = true;
            this.btn_PatientBacktoform3.Click += new System.EventHandler(this.btn_PatientBacktoform3_Click);
            // 
            // txtb_PatientEmail
            // 
            this.txtb_PatientEmail.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_PatientEmail.Location = new System.Drawing.Point(1112, 95);
            this.txtb_PatientEmail.Name = "txtb_PatientEmail";
            this.txtb_PatientEmail.Size = new System.Drawing.Size(200, 22);
            this.txtb_PatientEmail.TabIndex = 44;
            this.txtb_PatientEmail.TextChanged += new System.EventHandler(this.txtb_DoctorSchedule_TextChanged);
            // 
            // txtb_PatientIlness
            // 
            this.txtb_PatientIlness.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_PatientIlness.Location = new System.Drawing.Point(1098, 57);
            this.txtb_PatientIlness.Name = "txtb_PatientIlness";
            this.txtb_PatientIlness.Size = new System.Drawing.Size(224, 22);
            this.txtb_PatientIlness.TabIndex = 43;
            this.txtb_PatientIlness.TextChanged += new System.EventHandler(this.txtb_DoctorFee_TextChanged);
            // 
            // txtb_PatientContact
            // 
            this.txtb_PatientContact.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_PatientContact.Location = new System.Drawing.Point(710, 111);
            this.txtb_PatientContact.Name = "txtb_PatientContact";
            this.txtb_PatientContact.Size = new System.Drawing.Size(216, 22);
            this.txtb_PatientContact.TabIndex = 42;
            this.txtb_PatientContact.TextChanged += new System.EventHandler(this.txtb_DoctorContact_TextChanged);
            // 
            // lbl_PatientGender
            // 
            this.lbl_PatientGender.AutoSize = true;
            this.lbl_PatientGender.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientGender.Location = new System.Drawing.Point(605, 187);
            this.lbl_PatientGender.Name = "lbl_PatientGender";
            this.lbl_PatientGender.Size = new System.Drawing.Size(65, 19);
            this.lbl_PatientGender.TabIndex = 41;
            this.lbl_PatientGender.Text = "Gender";
            this.lbl_PatientGender.Click += new System.EventHandler(this.lbl_DoctorSchedule_Click);
            // 
            // lbl_PatiendAge
            // 
            this.lbl_PatiendAge.AutoSize = true;
            this.lbl_PatiendAge.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatiendAge.Location = new System.Drawing.Point(613, 71);
            this.lbl_PatiendAge.Name = "lbl_PatiendAge";
            this.lbl_PatiendAge.Size = new System.Drawing.Size(37, 19);
            this.lbl_PatiendAge.TabIndex = 40;
            this.lbl_PatiendAge.Text = "Age";
            this.lbl_PatiendAge.Click += new System.EventHandler(this.lbl_DoctorFee_Click);
            // 
            // lbl_PatientContact
            // 
            this.lbl_PatientContact.AutoSize = true;
            this.lbl_PatientContact.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientContact.Location = new System.Drawing.Point(605, 111);
            this.lbl_PatientContact.Name = "lbl_PatientContact";
            this.lbl_PatientContact.Size = new System.Drawing.Size(67, 19);
            this.lbl_PatientContact.TabIndex = 39;
            this.lbl_PatientContact.Text = "Contact";
            this.lbl_PatientContact.Click += new System.EventHandler(this.lbl_DoctorContact_Click);
            // 
            // txtb_PatientID
            // 
            this.txtb_PatientID.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_PatientID.Location = new System.Drawing.Point(334, 66);
            this.txtb_PatientID.Name = "txtb_PatientID";
            this.txtb_PatientID.Size = new System.Drawing.Size(218, 22);
            this.txtb_PatientID.TabIndex = 38;
            this.txtb_PatientID.TextChanged += new System.EventHandler(this.txtb_DoctorID_TextChanged);
            // 
            // lbl_PatientID
            // 
            this.lbl_PatientID.AutoSize = true;
            this.lbl_PatientID.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientID.Location = new System.Drawing.Point(205, 71);
            this.lbl_PatientID.Name = "lbl_PatientID";
            this.lbl_PatientID.Size = new System.Drawing.Size(85, 19);
            this.lbl_PatientID.TabIndex = 37;
            this.lbl_PatientID.Text = "Patient ID";
            this.lbl_PatientID.Click += new System.EventHandler(this.lbl_DoctorID_Click);
            // 
            // btn_PatientSearch
            // 
            this.btn_PatientSearch.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PatientSearch.Location = new System.Drawing.Point(362, 256);
            this.btn_PatientSearch.Name = "btn_PatientSearch";
            this.btn_PatientSearch.Size = new System.Drawing.Size(131, 39);
            this.btn_PatientSearch.TabIndex = 36;
            this.btn_PatientSearch.Text = "SEARCH";
            this.btn_PatientSearch.UseVisualStyleBackColor = true;
            this.btn_PatientSearch.Click += new System.EventHandler(this.btn_DoctorSearch_Click);
            // 
            // lbl_PatientMname
            // 
            this.lbl_PatientMname.AutoSize = true;
            this.lbl_PatientMname.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientMname.Location = new System.Drawing.Point(198, 185);
            this.lbl_PatientMname.Name = "lbl_PatientMname";
            this.lbl_PatientMname.Size = new System.Drawing.Size(109, 19);
            this.lbl_PatientMname.TabIndex = 35;
            this.lbl_PatientMname.Text = "Middle Name";
            this.lbl_PatientMname.Click += new System.EventHandler(this.lbl_DoctorSpecialist_Click);
            // 
            // lbl_PatientLname
            // 
            this.lbl_PatientLname.AutoSize = true;
            this.lbl_PatientLname.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientLname.Location = new System.Drawing.Point(205, 149);
            this.lbl_PatientLname.Name = "lbl_PatientLname";
            this.lbl_PatientLname.Size = new System.Drawing.Size(87, 19);
            this.lbl_PatientLname.TabIndex = 34;
            this.lbl_PatientLname.Text = "Last Name";
            this.lbl_PatientLname.Click += new System.EventHandler(this.lbl_DoctorLname_Click);
            // 
            // lbl_PatientFname
            // 
            this.lbl_PatientFname.AutoSize = true;
            this.lbl_PatientFname.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientFname.Location = new System.Drawing.Point(205, 109);
            this.lbl_PatientFname.Name = "lbl_PatientFname";
            this.lbl_PatientFname.Size = new System.Drawing.Size(93, 19);
            this.lbl_PatientFname.TabIndex = 33;
            this.lbl_PatientFname.Text = "First Name";
            this.lbl_PatientFname.Click += new System.EventHandler(this.lbl_DoctorFname_Click);
            // 
            // txtb_PatientMname
            // 
            this.txtb_PatientMname.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_PatientMname.Location = new System.Drawing.Point(334, 185);
            this.txtb_PatientMname.Name = "txtb_PatientMname";
            this.txtb_PatientMname.Size = new System.Drawing.Size(218, 22);
            this.txtb_PatientMname.TabIndex = 32;
            this.txtb_PatientMname.TextChanged += new System.EventHandler(this.txtb_DoctorSpecialist_TextChanged);
            // 
            // txtb_PatientLname
            // 
            this.txtb_PatientLname.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_PatientLname.Location = new System.Drawing.Point(334, 149);
            this.txtb_PatientLname.Name = "txtb_PatientLname";
            this.txtb_PatientLname.Size = new System.Drawing.Size(218, 22);
            this.txtb_PatientLname.TabIndex = 31;
            this.txtb_PatientLname.TextChanged += new System.EventHandler(this.txtb_DoctorLname_TextChanged);
            // 
            // txtb_PatientFname
            // 
            this.txtb_PatientFname.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_PatientFname.Location = new System.Drawing.Point(334, 106);
            this.txtb_PatientFname.Name = "txtb_PatientFname";
            this.txtb_PatientFname.Size = new System.Drawing.Size(218, 22);
            this.txtb_PatientFname.TabIndex = 30;
            this.txtb_PatientFname.TextChanged += new System.EventHandler(this.txtb_DoctorFname_TextChanged);
            // 
            // btn_PatientUpdate
            // 
            this.btn_PatientUpdate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PatientUpdate.Location = new System.Drawing.Point(25, 167);
            this.btn_PatientUpdate.Name = "btn_PatientUpdate";
            this.btn_PatientUpdate.Size = new System.Drawing.Size(131, 40);
            this.btn_PatientUpdate.TabIndex = 29;
            this.btn_PatientUpdate.Text = "UPDATE";
            this.btn_PatientUpdate.UseVisualStyleBackColor = true;
            this.btn_PatientUpdate.Click += new System.EventHandler(this.btn_DoctorUpdate_Click);
            // 
            // btn_PatientDelete
            // 
            this.btn_PatientDelete.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PatientDelete.Location = new System.Drawing.Point(25, 223);
            this.btn_PatientDelete.Name = "btn_PatientDelete";
            this.btn_PatientDelete.Size = new System.Drawing.Size(131, 40);
            this.btn_PatientDelete.TabIndex = 28;
            this.btn_PatientDelete.Text = "DELETE";
            this.btn_PatientDelete.UseVisualStyleBackColor = true;
            this.btn_PatientDelete.Click += new System.EventHandler(this.btn_DoctorDelete_Click);
            // 
            // btn_PatientInsert
            // 
            this.btn_PatientInsert.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PatientInsert.Location = new System.Drawing.Point(25, 106);
            this.btn_PatientInsert.Name = "btn_PatientInsert";
            this.btn_PatientInsert.Size = new System.Drawing.Size(131, 41);
            this.btn_PatientInsert.TabIndex = 27;
            this.btn_PatientInsert.Text = "INSERT";
            this.btn_PatientInsert.UseVisualStyleBackColor = true;
            this.btn_PatientInsert.Click += new System.EventHandler(this.btn_DoctorInsert_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(270, 240);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 56);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // txtb_PatientSearch
            // 
            this.txtb_PatientSearch.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_PatientSearch.Location = new System.Drawing.Point(516, 257);
            this.txtb_PatientSearch.Name = "txtb_PatientSearch";
            this.txtb_PatientSearch.Size = new System.Drawing.Size(571, 39);
            this.txtb_PatientSearch.TabIndex = 25;
            this.txtb_PatientSearch.TextChanged += new System.EventHandler(this.txtb_DoctorSearch_TextChanged);
            // 
            // dataGridViewPatient
            // 
            this.dataGridViewPatient.AllowUserToAddRows = false;
            this.dataGridViewPatient.AllowUserToDeleteRows = false;
            this.dataGridViewPatient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPatient.Location = new System.Drawing.Point(65, 336);
            this.dataGridViewPatient.Name = "dataGridViewPatient";
            this.dataGridViewPatient.ReadOnly = true;
            this.dataGridViewPatient.RowHeadersWidth = 51;
            this.dataGridViewPatient.RowTemplate.Height = 24;
            this.dataGridViewPatient.Size = new System.Drawing.Size(1238, 520);
            this.dataGridViewPatient.TabIndex = 24;
            this.dataGridViewPatient.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDoctor_CellContentClick);
            // 
            // txtb_PatientAge
            // 
            this.txtb_PatientAge.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_PatientAge.Location = new System.Drawing.Point(708, 71);
            this.txtb_PatientAge.Name = "txtb_PatientAge";
            this.txtb_PatientAge.Size = new System.Drawing.Size(218, 22);
            this.txtb_PatientAge.TabIndex = 45;
            // 
            // lbl_PatientIlness
            // 
            this.lbl_PatientIlness.AutoSize = true;
            this.lbl_PatientIlness.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientIlness.Location = new System.Drawing.Point(1001, 57);
            this.lbl_PatientIlness.Name = "lbl_PatientIlness";
            this.lbl_PatientIlness.Size = new System.Drawing.Size(52, 19);
            this.lbl_PatientIlness.TabIndex = 46;
            this.lbl_PatientIlness.Text = "Ilness";
            // 
            // lbl_PatientEmail
            // 
            this.lbl_PatientEmail.AutoSize = true;
            this.lbl_PatientEmail.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientEmail.Location = new System.Drawing.Point(999, 95);
            this.lbl_PatientEmail.Name = "lbl_PatientEmail";
            this.lbl_PatientEmail.Size = new System.Drawing.Size(54, 19);
            this.lbl_PatientEmail.TabIndex = 47;
            this.lbl_PatientEmail.Text = "Email";
            // 
            // cmb_PatientGender
            // 
            this.cmb_PatientGender.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_PatientGender.FormattingEnabled = true;
            this.cmb_PatientGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmb_PatientGender.Location = new System.Drawing.Point(710, 185);
            this.cmb_PatientGender.Name = "cmb_PatientGender";
            this.cmb_PatientGender.Size = new System.Drawing.Size(216, 23);
            this.cmb_PatientGender.TabIndex = 48;
            // 
            // lbl_PatientMedicine
            // 
            this.lbl_PatientMedicine.AutoSize = true;
            this.lbl_PatientMedicine.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientMedicine.Location = new System.Drawing.Point(999, 138);
            this.lbl_PatientMedicine.Name = "lbl_PatientMedicine";
            this.lbl_PatientMedicine.Size = new System.Drawing.Size(79, 19);
            this.lbl_PatientMedicine.TabIndex = 49;
            this.lbl_PatientMedicine.Text = "Medicine";
            // 
            // lbl_PatientRoom
            // 
            this.lbl_PatientRoom.AutoSize = true;
            this.lbl_PatientRoom.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientRoom.Location = new System.Drawing.Point(1003, 179);
            this.lbl_PatientRoom.Name = "lbl_PatientRoom";
            this.lbl_PatientRoom.Size = new System.Drawing.Size(53, 19);
            this.lbl_PatientRoom.TabIndex = 50;
            this.lbl_PatientRoom.Text = "Room";
            // 
            // txtb_PatientMedicine
            // 
            this.txtb_PatientMedicine.Location = new System.Drawing.Point(1112, 138);
            this.txtb_PatientMedicine.Name = "txtb_PatientMedicine";
            this.txtb_PatientMedicine.Size = new System.Drawing.Size(200, 22);
            this.txtb_PatientMedicine.TabIndex = 51;
            // 
            // txtb_PatientRoom
            // 
            this.txtb_PatientRoom.Location = new System.Drawing.Point(1112, 179);
            this.txtb_PatientRoom.Name = "txtb_PatientRoom";
            this.txtb_PatientRoom.Size = new System.Drawing.Size(200, 22);
            this.txtb_PatientRoom.TabIndex = 52;
            // 
            // lbl_PatientAddress
            // 
            this.lbl_PatientAddress.AutoSize = true;
            this.lbl_PatientAddress.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatientAddress.Location = new System.Drawing.Point(605, 149);
            this.lbl_PatientAddress.Name = "lbl_PatientAddress";
            this.lbl_PatientAddress.Size = new System.Drawing.Size(68, 19);
            this.lbl_PatientAddress.TabIndex = 53;
            this.lbl_PatientAddress.Text = "Address";
            // 
            // txtb_PatientAddress
            // 
            this.txtb_PatientAddress.Location = new System.Drawing.Point(710, 149);
            this.txtb_PatientAddress.Name = "txtb_PatientAddress";
            this.txtb_PatientAddress.Size = new System.Drawing.Size(216, 22);
            this.txtb_PatientAddress.TabIndex = 54;
            // 
            // frm_PatientInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1343, 880);
            this.Controls.Add(this.txtb_PatientAddress);
            this.Controls.Add(this.lbl_PatientAddress);
            this.Controls.Add(this.txtb_PatientRoom);
            this.Controls.Add(this.txtb_PatientMedicine);
            this.Controls.Add(this.lbl_PatientRoom);
            this.Controls.Add(this.lbl_PatientMedicine);
            this.Controls.Add(this.cmb_PatientGender);
            this.Controls.Add(this.lbl_PatientEmail);
            this.Controls.Add(this.lbl_PatientIlness);
            this.Controls.Add(this.txtb_PatientAge);
            this.Controls.Add(this.txtb_PatientEmail);
            this.Controls.Add(this.txtb_PatientIlness);
            this.Controls.Add(this.txtb_PatientContact);
            this.Controls.Add(this.lbl_PatientGender);
            this.Controls.Add(this.lbl_PatiendAge);
            this.Controls.Add(this.lbl_PatientContact);
            this.Controls.Add(this.txtb_PatientID);
            this.Controls.Add(this.lbl_PatientID);
            this.Controls.Add(this.btn_PatientSearch);
            this.Controls.Add(this.lbl_PatientMname);
            this.Controls.Add(this.lbl_PatientLname);
            this.Controls.Add(this.lbl_PatientFname);
            this.Controls.Add(this.txtb_PatientMname);
            this.Controls.Add(this.txtb_PatientLname);
            this.Controls.Add(this.txtb_PatientFname);
            this.Controls.Add(this.btn_PatientUpdate);
            this.Controls.Add(this.btn_PatientDelete);
            this.Controls.Add(this.btn_PatientInsert);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtb_PatientSearch);
            this.Controls.Add(this.dataGridViewPatient);
            this.Controls.Add(this.btn_PatientBacktoform3);
            this.Name = "frm_PatientInformation";
            this.Text = "Patient Information";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPatient)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_PatientBacktoform3;
        private System.Windows.Forms.TextBox txtb_PatientEmail;
        private System.Windows.Forms.TextBox txtb_PatientIlness;
        private System.Windows.Forms.TextBox txtb_PatientContact;
        private System.Windows.Forms.Label lbl_PatientGender;
        private System.Windows.Forms.Label lbl_PatiendAge;
        private System.Windows.Forms.Label lbl_PatientContact;
        private System.Windows.Forms.TextBox txtb_PatientID;
        private System.Windows.Forms.Label lbl_PatientID;
        private System.Windows.Forms.Button btn_PatientSearch;
        private System.Windows.Forms.Label lbl_PatientMname;
        private System.Windows.Forms.Label lbl_PatientLname;
        private System.Windows.Forms.Label lbl_PatientFname;
        private System.Windows.Forms.TextBox txtb_PatientMname;
        private System.Windows.Forms.TextBox txtb_PatientLname;
        private System.Windows.Forms.TextBox txtb_PatientFname;
        private System.Windows.Forms.Button btn_PatientUpdate;
        private System.Windows.Forms.Button btn_PatientDelete;
        private System.Windows.Forms.Button btn_PatientInsert;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtb_PatientSearch;
        private System.Windows.Forms.DataGridView dataGridViewPatient;
        private System.Windows.Forms.TextBox txtb_PatientAge;
        private System.Windows.Forms.Label lbl_PatientIlness;
        private System.Windows.Forms.Label lbl_PatientEmail;
        private System.Windows.Forms.ComboBox cmb_PatientGender;
        private System.Windows.Forms.Label lbl_PatientMedicine;
        private System.Windows.Forms.Label lbl_PatientRoom;
        private System.Windows.Forms.TextBox txtb_PatientMedicine;
        private System.Windows.Forms.TextBox txtb_PatientRoom;
        private System.Windows.Forms.Label lbl_PatientAddress;
        private System.Windows.Forms.TextBox txtb_PatientAddress;
    }
}