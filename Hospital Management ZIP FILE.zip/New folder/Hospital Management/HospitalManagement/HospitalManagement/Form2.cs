﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalManagement
{
    public partial class frm_AdminLogin : Form
    {
        public frm_AdminLogin()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btn_AdminLogin_Click(object sender, EventArgs e)
        {
            if (txtb_AdminUsername.Text  == "Admin")
            {
                if (txtb_AdminPassword.Text == "Admin123")
                {
                    new frm_Third_Info().Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Error: Please Enter the Correct Information");
                }
            }
            else
            {
                MessageBox.Show("Error: Please Enter the Correct Information");
            }
        }

        private void btn_UserEXIT_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            Application.Exit();
        }
    }
}
