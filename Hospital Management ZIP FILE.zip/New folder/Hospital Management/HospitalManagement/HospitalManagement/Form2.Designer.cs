﻿namespace HospitalManagement
{
    partial class frm_AdminLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_AdminLogin));
            this.panel_login = new System.Windows.Forms.Panel();
            this.lbl_Sec_NameHospital = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_AdminUsername = new System.Windows.Forms.Label();
            this.lbl_AdminPassword = new System.Windows.Forms.Label();
            this.txtb_AdminUsername = new System.Windows.Forms.TextBox();
            this.txtb_AdminPassword = new System.Windows.Forms.TextBox();
            this.btn_AdminLogin = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btn_UserEXIT = new System.Windows.Forms.Button();
            this.panel_login.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_login
            // 
            this.panel_login.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel_login.Controls.Add(this.lbl_Sec_NameHospital);
            this.panel_login.Controls.Add(this.pictureBox1);
            this.panel_login.Location = new System.Drawing.Point(12, 25);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(711, 109);
            this.panel_login.TabIndex = 0;
            // 
            // lbl_Sec_NameHospital
            // 
            this.lbl_Sec_NameHospital.AutoSize = true;
            this.lbl_Sec_NameHospital.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sec_NameHospital.ForeColor = System.Drawing.Color.Cyan;
            this.lbl_Sec_NameHospital.Location = new System.Drawing.Point(190, 37);
            this.lbl_Sec_NameHospital.Name = "lbl_Sec_NameHospital";
            this.lbl_Sec_NameHospital.Size = new System.Drawing.Size(440, 32);
            this.lbl_Sec_NameHospital.TabIndex = 1;
            this.lbl_Sec_NameHospital.Text = "ANGELES LIFELINE HOSPITAL";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(134, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_AdminUsername
            // 
            this.lbl_AdminUsername.AutoSize = true;
            this.lbl_AdminUsername.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AdminUsername.Location = new System.Drawing.Point(149, 229);
            this.lbl_AdminUsername.Name = "lbl_AdminUsername";
            this.lbl_AdminUsername.Size = new System.Drawing.Size(145, 25);
            this.lbl_AdminUsername.TabIndex = 1;
            this.lbl_AdminUsername.Text = "USERNAME";
            // 
            // lbl_AdminPassword
            // 
            this.lbl_AdminPassword.AutoSize = true;
            this.lbl_AdminPassword.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AdminPassword.Location = new System.Drawing.Point(149, 291);
            this.lbl_AdminPassword.Name = "lbl_AdminPassword";
            this.lbl_AdminPassword.Size = new System.Drawing.Size(141, 25);
            this.lbl_AdminPassword.TabIndex = 2;
            this.lbl_AdminPassword.Text = "PASSWORD";
            // 
            // txtb_AdminUsername
            // 
            this.txtb_AdminUsername.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_AdminUsername.Location = new System.Drawing.Point(372, 229);
            this.txtb_AdminUsername.Name = "txtb_AdminUsername";
            this.txtb_AdminUsername.Size = new System.Drawing.Size(213, 34);
            this.txtb_AdminUsername.TabIndex = 3;
            // 
            // txtb_AdminPassword
            // 
            this.txtb_AdminPassword.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_AdminPassword.Location = new System.Drawing.Point(372, 282);
            this.txtb_AdminPassword.Name = "txtb_AdminPassword";
            this.txtb_AdminPassword.PasswordChar = '*';
            this.txtb_AdminPassword.Size = new System.Drawing.Size(213, 34);
            this.txtb_AdminPassword.TabIndex = 4;
            // 
            // btn_AdminLogin
            // 
            this.btn_AdminLogin.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AdminLogin.Location = new System.Drawing.Point(135, 404);
            this.btn_AdminLogin.Name = "btn_AdminLogin";
            this.btn_AdminLogin.Size = new System.Drawing.Size(155, 39);
            this.btn_AdminLogin.TabIndex = 5;
            this.btn_AdminLogin.Text = "LOGIN";
            this.btn_AdminLogin.UseVisualStyleBackColor = true;
            this.btn_AdminLogin.Click += new System.EventHandler(this.btn_AdminLogin_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(87, 223);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 40);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(88, 282);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(40, 40);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // btn_UserEXIT
            // 
            this.btn_UserEXIT.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UserEXIT.Location = new System.Drawing.Point(430, 404);
            this.btn_UserEXIT.Name = "btn_UserEXIT";
            this.btn_UserEXIT.Size = new System.Drawing.Size(155, 39);
            this.btn_UserEXIT.TabIndex = 9;
            this.btn_UserEXIT.Text = "EXIT";
            this.btn_UserEXIT.UseVisualStyleBackColor = true;
            this.btn_UserEXIT.Click += new System.EventHandler(this.btn_UserEXIT_Click);
            // 
            // frm_AdminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 503);
            this.Controls.Add(this.btn_UserEXIT);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btn_AdminLogin);
            this.Controls.Add(this.txtb_AdminPassword);
            this.Controls.Add(this.txtb_AdminUsername);
            this.Controls.Add(this.lbl_AdminPassword);
            this.Controls.Add(this.lbl_AdminUsername);
            this.Controls.Add(this.panel_login);
            this.Name = "frm_AdminLogin";
            this.Text = "AdminLogin";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_login;
        private System.Windows.Forms.Label lbl_Sec_NameHospital;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_AdminUsername;
        private System.Windows.Forms.Label lbl_AdminPassword;
        private System.Windows.Forms.TextBox txtb_AdminUsername;
        private System.Windows.Forms.TextBox txtb_AdminPassword;
        private System.Windows.Forms.Button btn_AdminLogin;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btn_UserEXIT;
    }
}